DELETE 
FROM Prenotazioni
WHERE PrenotazioneId = 11 or PrenotazioneId = 12;

SELECT * 
FROM Prenotazioni;