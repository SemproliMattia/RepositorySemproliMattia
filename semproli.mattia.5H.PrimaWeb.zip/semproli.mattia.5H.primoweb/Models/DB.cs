using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace semproli.mattia._5H.primoweb.Models
{
    public class PrenotazioneContext : DbContext
    {
        public DbSet<Prenotazione> Prenotazioni { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
            => options.UseSqlite("Data Source=database.db");
    }
}