﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using semproli.mattia._5H.primoweb.Models;

namespace semproli.mattia._5H.primoweb.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Cancella()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Prenota()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Prenota(Prenotazione p)
        {
            //tipo - etichetta - operatore - valore - terminatore di istruzione
            //int a = 10;

            //tipo - etichetta - operatore - valore - terminatore di istruzione
            var db = new PrenotazioneContext();

            db.Prenotazioni.Add(p);
            db.SaveChanges();
            
            return View("Grazie" , db);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
